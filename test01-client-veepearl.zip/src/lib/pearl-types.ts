export const pearlTypes = [
    {
        name: 'Ring',
        image: 'type-ring.webp'
    },
    {
        name: 'Necklace',
        image: 'type-necklare.webp'
    },
    {
        name: 'Earring',
        image: 'type-earings.webp'
    },
    {
        name: 'Bracelet',
        image: 'type-bracelet.webp'
    },
    {
        name: 'Brooch',
        image: 'type-brooch.webp'
    },
    {
        name: 'Sets of Jewellery',
        image: 'type-sets-jewellery.webp'
    },
]