import { heading } from "@/components/ui/font-family";
import { AboutPearls, PearlType } from "@/types/global-types";

export const aboutPearls: AboutPearls = {
  heading: "What is Pearls",
  body: [
    "Pearls are a symbol of purity and innocence, and are believed to bring clarity and wisdom. This stone is said to help one find inner peace and increase self-acceptance.",
    "Indonesia is recorded as the largest producer of South Sea pearl commodities in the world.",
    "The process of forming pearls is very rare and takes a long time, making pearls a very valuable. In addition, pearls are also a symbol of beauty, luxury, and eternity, so many people consider pearls to be very special and valuable.",
    "Pearls are generally white or ivory in color. But they can also be light pink, yellow, or even black.",
    "Pearls contain more than 30 types of minerals such as magnesium and calcium that can maintain healthy skin. The protein contained in pearls can also increase collagen production, increase skin moisture and make it look brighter.",
    "Pearls are more popular with a perfectly round shape, but the shape is not always round, there are other pearl shapes such as semi-round, drop, baroque, and circle baroque which are considered rarer and more unique.",
  ],
  image: "bg-about-pearl1.jpg",
};

export const pearlTypes: PearlType = {
  heading: "Pearl Types",
  body: "Since Veepearls offers such a wide range of pearl types, our customers can often times be confused on which type of pearl offers the best value at their budget. Read our brief summaries below to educate yourself regarding the origin, value, size and quality of each pearl type.",
  pearl_type: [
    {
      name_type: "Freshwater Pearls",
      description:
        "Freshwater pearls are typically found in lakes and rivers in China. In recent years, the quality of Freshwater pearls has drastically improved and has resulted in beautiful pearls that are cleaner, rounder, and more lustrous. Due to their mass production, freshwater pearls are also popular for their affordable price points.",
      image: "freshwater-pearl.png",
      color_bg: "#E3C1C1",
    },
    {
      name_type: "Japanese Akoya Pearls",
      description:
        "Since the 1930's, Akoya pearls are the world's best-known pearl. Akoya pearls are often very round and spherical in shape and are complemented by very high luster. Produced by a small oyster called the Pinctada Fucata off the seas of Japan and China, they are commonly found in sizes ranging from 2mm to 10mm in size. ",
      image: "akoya-pearl.png",
      color_bg: "#F3F3F4",
    },
    {
      name_type: "White & Golden South Sea Pearls",
      description:
        "White & Golden South Sea pearls are cherished for their classic color as well as their exceptional sizes. These rare gems are produced by the Pinctada Maxima oyster, found in very deep and offshore waters. White South Sea pearls are commonly found off the shores of Australia and are typically creamy white in color with a silver overtone.",
      image: "south-sea-whitegolden-pearls.png",
      color_bg: "#FFFFFF",
    },
    {
      name_type: "Tahitian South Sea Pearls",
      description:
        "Tahitian pearls, also known as black South Sea pearls or simply black pearls, are cherished for their incredibly exotic colors and mirror-like luster. Whereas other pearl types are typically limited in color, Tahitian pearls consist of hundreds of overtones with incredibly exotic colors such as peacock green, silver green, blue, and eggplant, just to name a few.",
      image: "tahitian-south-pearls.png",
      color_bg: "#C2C5CF",
    },
  ],
};
