export const testimoniData = [
    {
        name: "Andrey",
        comment: "How wonderfull necklace, good quality",
    },
    {
        name: "Vicky",
        comment: "I got very surprise everything perfect package amazing, for sure i will buy again, love pearl 💕",
    }
]