import LogoVeepearl from '../../public/images/img-logo-veepearl.svg'

export const images = {
  LogoVeepearl,
}